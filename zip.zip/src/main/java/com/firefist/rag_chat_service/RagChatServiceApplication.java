package com.firefist.rag_chat_service;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RagChatServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(RagChatServiceApplication.class, args);
	}

}
