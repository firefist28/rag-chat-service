package com.firefist.rag_chat_service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RagChatServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
